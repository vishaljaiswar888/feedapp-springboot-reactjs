package com.example.demo.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Entity
public class User {
    @Id
    @GeneratedValue
    @Column(name = "user_id")
    private Long userId;
    
    @NotEmpty
    @Column(name = "user_name")
    private String userName;
    
    @NotEmpty
    @Email
    @Column(name = "user_email")
    private String userEmail;
    
    @NotEmpty
    @Column(name = "user_phone")
    private String userPhone;
    
    @Transient
    private String userPass;

    @Column(name = "user_pass_encrypted")
    private String userPassEncrypted;

    @Column(name = "user_role")
    private String userRole = "Customer";
    
    private String encryptPassword(String password) {
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        return passwordEncoder.encode(password);
    }

	public User(Long userId, @NotEmpty String userName, @NotEmpty @Email String userEmail, @NotEmpty String userPhone,
			String userPass, String userPassEncrypted, String userRole) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.userPass = userPass;
		this.userPassEncrypted = userPassEncrypted;
		this.userRole = userRole;
	}
	
	public User() {
		
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
		this.userPassEncrypted = encryptPassword(userPass);
	}

	public String getUserPassEncrypted() {
		return userPassEncrypted;
	}

	public void setUserPassEncrypted(String userPassEncrypted) {
		this.userPassEncrypted = userPassEncrypted;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
}
