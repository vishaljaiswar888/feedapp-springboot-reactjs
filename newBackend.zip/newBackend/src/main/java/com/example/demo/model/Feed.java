package com.example.demo.model;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
public class Feed {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "feed_id")
    private Long feedId;

    @NotEmpty
    @Column(name = "post_description")
    private String postDescription;

    @NotEmpty
    @Column(name = "created_by")
    private String createdBy;

    @NotNull
    @Column(name = "date_created")
    private Date dateCreated;
    
    @NotNull
    @Column(name = "approval")
    private String approval = "Not Approved";

    @Column(name = "no_of_likes")
    private int noOfLikes = 0;

    @ElementCollection
    private Set<String> likedByUsers = new HashSet<>();

    public Feed() {
    }

    public Feed(Long feedId, @NotEmpty String postDescription, @NotEmpty String createdBy, @NotNull Date dateCreated, @NotNull String approval) {
        super();
        this.feedId = feedId;
        this.postDescription = postDescription;
        this.createdBy = createdBy;
        this.dateCreated = dateCreated;
        this.approval = approval; 
        this.noOfLikes = 0; 
    }

    // Getters and setters
    public Long getFeedId() {
        return feedId;
    }

    public void setFeedId(Long feedId) {
        this.feedId = feedId;
    }

    public String getPostDescription() {
        return postDescription;
    }

    public void setPostDescription(String postDescription) {
        this.postDescription = postDescription;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getApproval() {
        return approval;
    }

    public void setApproval(String approval) {
        this.approval = approval;
    }

    public int getNoOfLikes() {
        return noOfLikes;
    }

    public void setNoOfLikes(int noOfLikes) {
        this.noOfLikes = noOfLikes;
    }

    public Set<String> getLikedByUsers() {
        return likedByUsers;
    }

    public void setLikedByUsers(Set<String> likedByUsers) {
        this.likedByUsers = likedByUsers;
    }
}
