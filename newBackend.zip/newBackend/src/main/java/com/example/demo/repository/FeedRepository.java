package com.example.demo.repository;

import com.example.demo.model.Feed;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedRepository extends JpaRepository<Feed, Long> {
	List<Feed> findByCreatedBy(String createdBy);
}
