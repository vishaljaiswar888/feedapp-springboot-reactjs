package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Feed;
import com.example.demo.repository.FeedRepository;

@Service
public class FeedService {
	@Autowired
    private FeedRepository feedRepository;

    public List<Feed> getFeedsByCreatedBy(String createdBy) {
        return feedRepository.findByCreatedBy(createdBy);
    }
}