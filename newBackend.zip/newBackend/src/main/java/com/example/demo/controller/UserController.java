package com.example.demo.controller;

import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@CrossOrigin("http://localhost:3000")
public class UserController {
    
    @Autowired
    private UserRepository userRepository;

    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginUser, HttpSession session) {
        Optional<User> userOptional = userRepository.findByUserEmail(loginUser.getUserEmail());
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            
            if (passwordEncoder.matches(loginUser.getUserPass(), user.getUserPassEncrypted())) {
                Map<String, Object> userData = new HashMap<>();
                userData.put("userId", user.getUserId());
                userData.put("userEmail", user.getUserEmail());
                userData.put("userPhone", user.getUserPhone());
                userData.put("userName", user.getUserName());
                userData.put("userRole", user.getUserRole());

                session.setAttribute("userData", userData);

                return ResponseEntity.ok(userData);
            }
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "Logout successful";
    }

    @PostMapping("/addUser")
    public User newUser(@RequestBody User newUser) {
        // Encrypt the password before saving
        newUser.setUserPass(newUser.getUserPass());
        return userRepository.save(newUser);
    }

    @GetMapping("/fetchAllUsers")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/fetchUserById/{id}")
    public User getUserById(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
    }

    @PutMapping("/updateUserById/{id}")
    public User updateUser(@RequestBody User newUser, @PathVariable Long id) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setUserName(newUser.getUserName());
                    user.setUserEmail(newUser.getUserEmail());
                    user.setUserPhone(newUser.getUserPhone());
                    if (newUser.getUserPass() != null && !newUser.getUserPass().isEmpty()) {
                        user.setUserPass(newUser.getUserPass());
                    }
                    user.setUserRole(newUser.getUserRole());
                    return userRepository.save(user);
                }).orElseThrow(() -> new UserNotFoundException(id));
    }
    

    @DeleteMapping("/deleteUserById/{id}")
    public String deleteUser(@PathVariable Long id) {
        if (!userRepository.existsById(id)) {
            throw new UserNotFoundException(id);
        }
        userRepository.deleteById(id);
        return "User with id " + id + " has been deleted successfully!";
    }

}
