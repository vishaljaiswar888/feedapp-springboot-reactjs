package com.example.demo.controller;

import com.example.demo.model.Feed;
import com.example.demo.repository.FeedRepository;
import com.example.demo.service.FeedService;
import com.example.demo.exception.FeedNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("http://localhost:3000")
public class FeedController {
    
    @Autowired
    private FeedRepository feedRepository;
    
    @Autowired
    private FeedService feedService;

    @GetMapping("/fetchFeedsByCreatedBy")
    public List<Feed> getFeedsByCreatedBy(@RequestParam String createdBy) {
        return feedService.getFeedsByCreatedBy(createdBy);
    }

    @PostMapping("/addFeed")
    public Feed newFeed(@RequestBody Feed newFeed) {
        return feedRepository.save(newFeed);
    }

    @GetMapping("/fetchAllFeeds")
    public List<Feed> getAllFeeds() {
        return feedRepository.findAll();
    }

    @GetMapping("/fetchFeedById/{id}")
    public Feed getFeedById(@PathVariable Long id) {
        return feedRepository.findById(id)
                .orElseThrow(() -> new FeedNotFoundException(id));
    }
    
    

    @PutMapping("/updateFeedById/{id}")
    public Feed updateFeed(@RequestBody Feed newFeed, @PathVariable Long id) {
        return feedRepository.findById(id)
                .map(feed -> {
                    feed.setPostDescription(newFeed.getPostDescription());
                    feed.setDateCreated(newFeed.getDateCreated());
                    feed.setCreatedBy(newFeed.getCreatedBy());
                    feed.setApproval(newFeed.getApproval());
                    feed.setNoOfLikes(newFeed.getNoOfLikes());
                    return feedRepository.save(feed);
                }).orElseThrow(() -> new FeedNotFoundException(id));
    }
    
    
    
//    @PostMapping("/likeFeed/{id}")
//    public ResponseEntity<?> likeFeed(@PathVariable Long id, @RequestParam String userEmail) {
//        Feed feed = feedRepository.findById(id).orElseThrow(() -> new RuntimeException("Feed not found"));
//        if (feed.getLikedByUsers().contains(userEmail)) {
//            return ResponseEntity.badRequest().body("User has already liked this feed");
//        }
//        feed.getLikedByUsers().add(userEmail);
//        feed.setNoOfLikes(feed.getNoOfLikes() + 1);
//        feedRepository.save(feed);
//        return ResponseEntity.ok("Feed liked successfully");
//    }
    
    
    @PostMapping("/likeFeed/{id}")
    public ResponseEntity<?> likeFeed(@PathVariable Long id, @RequestParam String userEmail) {
        Feed feed = feedRepository.findById(id).orElseThrow(() -> new RuntimeException("Feed not found"));
        if (feed.getLikedByUsers().contains(userEmail)) {
            feed.getLikedByUsers().remove(userEmail);
            feed.setNoOfLikes(feed.getNoOfLikes() - 1);
        } else {
            feed.getLikedByUsers().add(userEmail);
            feed.setNoOfLikes(feed.getNoOfLikes() + 1);
        }
        feedRepository.save(feed);
        return ResponseEntity.ok("Feed like status updated successfully");
    }
    
    
    

    @DeleteMapping("/deleteFeedById/{id}")
    public String deleteFeed(@PathVariable Long id) {
        if (!feedRepository.existsById(id)) {
            throw new FeedNotFoundException(id);
        }
        feedRepository.deleteById(id);
        return "Feed with id " + id + " has been deleted successfully!";
    }
}
