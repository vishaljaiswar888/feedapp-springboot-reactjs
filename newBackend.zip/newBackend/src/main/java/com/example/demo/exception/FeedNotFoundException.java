package com.example.demo.exception;

public class FeedNotFoundException extends RuntimeException {
	public FeedNotFoundException(Long id) {
		super("Could not found the feed with id " + id);
	}
}
