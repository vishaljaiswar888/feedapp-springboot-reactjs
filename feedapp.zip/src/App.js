import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import {Routes, Route} from "react-router-dom";
import Login from './components/Login';
import AddFeed from './Feed/AddFeed';
import AllFeed from './Feed/AllFeed';
import AllFeedAdmin from './Feed/AllFeedAdmin';
import AllFeedAdminApproved from './Feed/AllFeedAdminApproved';
import EditFeed from './Feed/EditFeed';
import AdminPanel from './Panel/AdminPanel';
import UserPanel from './Panel/UserPanel';
import ViewFeed from './Feed/ViewFeed';
import UserFeed from './Feed/UserFeed';
import Register from './components/Register';
import EditUser from './User/EditUser';
import AllUsers from './User/AllUsers';
import ViewUsers from './User/ViewUsers';
import EditFeedAdmin from './Feed/EditFeedAdmin';

function App() {
  return (
    <div>
      <Routes>
        <Route path='/login' element={<Login />}/>
        <Route path='/viewFeed/:id' element={<ViewFeed />}/>
        <Route path='/addFeed' element={<AddFeed />}/>
        <Route path='/allFeed' element={<AllFeed />}/>
        <Route path='/adminPanel' element={<AdminPanel />}/>
        <Route path='/userPanel' element={<UserPanel />}/>
        <Route path='/allFeedAdmin' element={<AllFeedAdmin />}/>
        <Route path='/allFeedAdminApproved' element={<AllFeedAdminApproved />}/>
        <Route path='/editFeed/:id' element={<EditFeed />}/>
        <Route path='/editFeedAdmin/:id' element={<EditFeedAdmin />}/>
        <Route path='/editUser/:id' element={<EditUser />}/>
        <Route path="/userFeed" element={<UserFeed />} />
        <Route path="/register" element={<Register />} />
        <Route path="/allUsers" element={<AllUsers />} />
        <Route path="/viewUsers/:id" element={<ViewUsers />} />
      </Routes>
    </div>
  );
}

export default App;
