import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const ViewFeed = () => {
  const [feed, setFeed] = useState({
    postDescription: "",
    dateCreated: "",
    createdBy: "",
    approval: "",
  });

  const { id } = useParams();

  useEffect(() => {
    loadFeed();
  }, []);

  const loadFeed = async () => {
    const result = await axios.get(`http://localhost:8080/fetchFeedById/${id}`);
    setFeed(result.data);
  };

  return (
    <div>
      <div className="container mt-2">
        <section className="d-flex justify-content-between">
          <div className="left_data mt-2 p-3" style={{ width: "100%" }}>
            <h3 className="text-center col-lg-12 my-5">Feed Detail</h3>
            <div className="row gutters-sm mt-3 justify-content-center">
              <div className="col-md-8">
                <div className="card mb-3">
                  <div className="card-body">
                    <div className="row">
                      <div className="col-sm-3">
                        <h6 className="mb-0">Post Description</h6>
                      </div>
                      <div className="col-sm-9 text-secondary">
                        {feed.postDescription}
                      </div>
                    </div>
                    <br />
                    <div className="row">
                      <div className="col-sm-3">
                        <h6 className="mb-0">Date Created</h6>
                      </div>
                      <div className="col-sm-9 text-secondary">
                        {feed.dateCreated}
                      </div>
                    </div>
                    <br />
                    <div className="row">
                      <div className="col-sm-3">
                        <h6 className="mb-0">Created By</h6>
                      </div>
                      <div className="col-sm-9 text-secondary">
                        {feed.createdBy}
                      </div>
                    </div>
                    <br />
                    <div className="row"> {/* New Approval Status Row */}
                      <div className="col-sm-3">
                        <h6 className="mb-0">Approval Status</h6>
                      </div>
                      <div className="col-sm-9 text-secondary">
                        {feed.approval}
                      </div>
                    </div>
                    <br />
                    {/* Uncomment this if you want a Back button */}
                    {/* <div className="row">
                      <div className="col-sm-12">
                        <Link to="/allFeed" className="btn btn-primary mx-2">Back</Link>
                      </div>
                    </div> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default ViewFeed;





// import axios from "axios";
// import React, { useEffect, useState } from "react";
// import { useParams } from "react-router-dom";

// const ViewFeed = () => {
//   const [feed, setFeed] = useState({
//     postDescription: "",
//     dateCreated: "",
//     createdBy: "",
//   });

//   const { id } = useParams();

//   useEffect(() => {
//     loadFeed();
//   }, []);

//   const loadFeed = async () => {
//     const result = await axios.get(`http://localhost:8080/fetchFeedById/${id}`);
//     setFeed(result.data);
//   };

//   return (
//     <div>
//       <div>
//         <div className="container mt-2">
//           <section className="d-flex justify-content-between">
//             <div className="left_data mt-2 p-3" style={{ width: "100%" }}>
//               <h3 className="text-center col-lg-12 my-5">Feed Detail</h3>

//               <div className="row gutters-sm mt-3 justify-content-center">
//                 <div className="col-md-8">
//                   <div className="card mb-3">
//                     <div className="card-body">
//                       <div className="row">
//                         <div className="col-sm-3">
//                           <h6 className="mb-0">Post Description</h6>
//                         </div>
//                         <div className="col-sm-9 text-secondary">
//                           {feed.postDescription}
//                         </div>
//                       </div>
//                       <br />
//                       <div className="row">
//                         <div className="col-sm-3">
//                           <h6 className="mb-0">Date Created</h6>
//                         </div>
//                         <div className="col-sm-9 text-secondary">
//                           {feed.dateCreated}
//                         </div>
//                       </div>
//                       <br />
//                       <div className="row">
//                         <div className="col-sm-3">
//                           <h6 className="mb-0">Created By</h6>
//                         </div>
//                         <div className="col-sm-9 text-secondary">
//                           {feed.createdBy}
//                         </div>
//                       </div>
//                       <br />
//                       {/* <div className="row">
//                     <div className="col-sm-12">
//                         <Link to="/allVehicleDetail" className="btn btn-primary mx-2">Back</Link>
//                     </div>
//                 </div> */}
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </section>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ViewFeed;
