import React, { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
import axios from "axios";

const AllFeedAdmin = () => {
  const [feeds, setFeeds] = useState([]);

  useEffect(() => {
    loadFeeds();
  }, []);

  const loadFeeds = async () => {
    const result = await axios.get("http://localhost:8080/fetchAllFeeds");
    const notApprovedFeeds = result.data.filter(feed => feed.approval === "Not Approved");
    setFeeds(notApprovedFeeds);
  };

  const deleteFeed = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this feed?"
    );

    if (confirmDelete) {
      await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
      loadFeeds();
    }
  };

  const updateApproval = async (feed) => {
    const confirmUpdate = window.confirm(
      `Are you sure you want to update the approval status to "${feed.approval}"?`
    );

    if (confirmUpdate) {
      await axios.put(`http://localhost:8080/updateFeedById/${feed.feedId}`, feed);
      loadFeeds();
    }
  };

  const handleApprovalChange = (feed, event) => {
    const updatedFeed = { ...feed, approval: event.target.value };
    updateApproval(updatedFeed);
  };

  return (
    <div>
      <div className="container">
        <div className="py-4">
          <h2 className="text-center">All Feeds</h2>
          <Table striped="columns" className="border mt-3">
            <thead>
              <tr>
                <th>Sr</th>
                <th>Feed</th>
                <th>Created By</th>
                <th>Date Created</th>
                <th>Approval</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {feeds.map((feed, index) => (
                <tr key={feed.feedId}>
                  <td>{index + 1}</td>
                  <td>{feed.postDescription}</td>
                  <td>{feed.createdBy}</td>
                  <td>{feed.dateCreated}</td>
                  <td>
                    <select
                      value={feed.approval}
                      onChange={(event) => handleApprovalChange(feed, event)}
                    >
                      <option value="Approved">Approved</option>
                      <option value="Not Approved">Not Approved</option>
                    </select>
                  </td>
                  <td>
                    {/* <Link
                      className="btn btn-primary mx-2"
                      to={`/viewFeed/${feed.feedId}`}
                    >
                      View
                    </Link>
                    <Link
                      className="btn btn-outline-primary mx-2"
                      to={`/editFeedAdmin/${feed.feedId}`}
                    >
                      Edit
                    </Link> */}
                    <button
                      className="btn btn-danger mx-2"
                      onClick={() => deleteFeed(feed.feedId)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default AllFeedAdmin;








// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeedAdmin = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//     const notApprovedFeeds = result.data.filter(feed => feed.approval === "Not Approved");
//     setFeeds(notApprovedFeeds);
//   };

//   const deleteFeed = async (id) => {
//     const confirmDelete = window.confirm(
//       "Are you sure you want to delete this feed?"
//     );

//     if (confirmDelete) {
//       await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
//       loadFeeds();
//     }
//   };

//   return (
//     <div>
//       <div>
//         <div className="container">
//           <div className="py-4">
//             <h2 className="text-center">All Feeds</h2>
//             <Table striped="columns" className="border mt-3">
//               <thead>
//                 <tr>
//                   <th>Sr</th>
//                   <th>Feed</th>
//                   <th>Created By</th>
//                   <th>Date Created</th>
//                   <th>Action</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {feeds.map((feed, index) => (
//                   <tr key={feed.feedId}>
//                     <td>{index + 1}</td>
//                     <td>{feed.postDescription}</td>
//                     <td>{feed.createdBy}</td>
//                     <td>{feed.dateCreated}</td>
//                     <td>
//                       <Link
//                         className="btn btn-primary mx-2"
//                         to={`/viewFeed/${feed.feedId}`}
//                       >
//                         View
//                       </Link>
//                       <Link
//                         className="btn btn-outline-primary mx-2"
//                         to={`/editFeedAdmin/${feed.feedId}`}
//                       >
//                         Edit
//                       </Link>
//                       <button
//                         className="btn btn-danger mx-2"
//                         onClick={() => deleteFeed(feed.feedId)}
//                       >
//                         Delete
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </Table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeedAdmin;





// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeedAdmin = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//     setFeeds(result.data);
//   };

//   const deleteFeed = async (id) => {
//     const confirmDelete = window.confirm(
//       "Are you sure you want to delete this feed?"
//     );

//     if (confirmDelete) {
//       await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
//       loadFeeds();
//     }
//   };

//   return (
//     <div>
//       <div>
//         <div className="container">
//           <div className="py-4">
//             <h2 className="text-center">All Feeds</h2>
//             <Table striped="columns" className="border mt-3">
//               <thead>
//                 <tr>
//                   <th>Sr</th>
//                   <th>Feed</th>
//                   <th>Created By</th>
//                   <th>Date Created</th>
//                   <th>Action</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {feeds.map((feed, index) => (
//                   <tr key={feed.feedId}>
//                     <td>{index + 1}</td>
//                     <td>{feed.postDescription}</td>
//                     <td>{feed.createdBy}</td>
//                     <td>{feed.dateCreated}</td>
//                     <td>
//                       <Link
//                         className="btn btn-primary mx-2"
//                         to={`/viewFeed/${feed.feedId}`}
//                       >
//                         View
//                       </Link>
//                       <Link
//                         className="btn btn-outline-primary mx-2"
//                         to={`/editFeedAdmin/${feed.feedId}`}
//                       >
//                         Edit
//                       </Link>
//                       <button
//                         className="btn btn-danger mx-2"
//                         onClick={() => deleteFeed(feed.feedId)}
//                       >
//                         Delete
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </Table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeedAdmin;

