import React, { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
import axios from "axios";
import { Link } from "react-router-dom";

const AllFeed = () => {
  const [feeds, setFeeds] = useState([]);

  useEffect(() => {
    loadFeeds();
  }, []);

  const loadFeeds = async () => {
    const userData = JSON.parse(localStorage.getItem("userData"));
    if (userData && userData.userEmail) {
      const userEmail = userData.userEmail;
      try {
        const result = await axios.get("http://localhost:8080/fetchAllFeeds");
        const approvedFeeds = result.data.filter(
          (feed) => feed.approval === "Approved" && feed.createdBy !== userEmail
        );
        setFeeds(approvedFeeds);
      } catch (error) {
        console.error("Error fetching feeds", error);
      }
    } else {
      console.error("User email not found in localStorage");
    }
  };

  const toggleLike = async (id) => {
    const userData = JSON.parse(localStorage.getItem("userData"));
    if (userData && userData.userEmail) {
      const userEmail = userData.userEmail;
      try {
        await axios.post(`http://localhost:8080/likeFeed/${id}`, null, {
          params: { userEmail }
        });
        loadFeeds();
      } catch (error) {
        console.error("Error toggling like status", error);
      }
    } else {
      console.error("User email not found in localStorage");
    }
  };

  return (
    <div>
      <div className="container">
        <div className="py-4">
          <h2 className="text-center">All Approved Feeds</h2>
          <Table striped="columns" className="border mt-3">
            <thead>
              <tr>
                <th>Sr</th>
                <th>Feed</th>
                <th>Created By</th>
                <th>Date Created</th>
                <th>Approval</th>
                <th>Likes</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {feeds.map((feed, index) => (
                <tr key={feed.feedId}>
                  <td>{index + 1}</td>
                  <td>{feed.postDescription}</td>
                  <td>{feed.createdBy}</td>
                  <td>{feed.dateCreated}</td>
                  <td>{feed.approval}</td>
                  <td>{feed.noOfLikes}</td>
                  <td>
                    <Link
                      className="btn btn-primary mx-2"
                      to={`/viewFeed/${feed.feedId}`}
                    >
                      View
                    </Link>
                    <button
                      className="btn btn-success mx-2"
                      onClick={() => toggleLike(feed.feedId)}
                    >
                      {feed.likedByUsers.includes(
                        JSON.parse(localStorage.getItem("userData")).userEmail
                      )
                        ? "Unlike"
                        : "Like"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default AllFeed;




// current pro 2

// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeed = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     const userData = JSON.parse(localStorage.getItem("userData"));
//     if (userData && userData.userEmail) {
//       const userEmail = userData.userEmail;
//       try {
//         const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//         const approvedFeeds = result.data.filter(
//           (feed) => feed.approval === "Approved" && feed.createdBy !== userEmail
//         );
//         setFeeds(approvedFeeds);
//       } catch (error) {
//         console.error("Error fetching feeds", error);
//       }
//     } else {
//       console.error("User email not found in localStorage");
//     }
//   };

//   const likeFeed = async (id) => {
//     const userData = JSON.parse(localStorage.getItem("userData"));
//     if (userData && userData.userEmail) {
//       const userEmail = userData.userEmail;
//       try {
//         await axios.post(`http://localhost:8080/likeFeed/${id}`, null, {
//           params: { userEmail }
//         });
//         loadFeeds(); 
//       } catch (error) {
//         console.error("Error liking feed", error);
//       }
//     } else {
//       console.error("User email not found in localStorage");
//     }
//   };

//   return (
//     <div>
//       <div className="container">
//         <div className="py-4">
//           <h2 className="text-center">All Approved Feeds</h2>
//           <Table striped="columns" className="border mt-3">
//             <thead>
//               <tr>
//                 <th>Sr</th>
//                 <th>Feed</th>
//                 <th>Created By</th>
//                 <th>Date Created</th>
//                 <th>Approval</th>
//                 <th>Likes</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {feeds.map((feed, index) => (
//                 <tr key={feed.feedId}>
//                   <td>{index + 1}</td>
//                   <td>{feed.postDescription}</td>
//                   <td>{feed.createdBy}</td>
//                   <td>{feed.dateCreated}</td>
//                   <td>{feed.approval}</td>
//                   <td>{feed.noOfLikes}</td>
//                   <td>
//                     <Link
//                       className="btn btn-primary mx-2"
//                       to={`/viewFeed/${feed.feedId}`}
//                     >
//                       View
//                     </Link>
//                     <button
//                       className="btn btn-success mx-2"
//                       onClick={() => likeFeed(feed.feedId)}
//                     >
//                       Like
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </Table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeed;








// current pro

// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeed = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     const userData = JSON.parse(localStorage.getItem("userData"));
//     if (userData && userData.userEmail) {
//       const userEmail = userData.userEmail;
//       try {
//         const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//         const approvedFeeds = result.data.filter(
//           (feed) => feed.approval === "Approved" && feed.createdBy !== userEmail
//         );
//         setFeeds(approvedFeeds);
//       } catch (error) {
//         console.error("Error fetching feeds", error);
//       }
//     } else {
//       console.error("User email not found in localStorage");
//     }
//   };

//   const deleteFeed = async (id) => {
//     const confirmDelete = window.confirm(
//       "Are you sure you want to delete this feed?"
//     );

//     if (confirmDelete) {
//       try {
//         await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
//         loadFeeds(); 
//       } catch (error) {
//         console.error("Error deleting feed", error);
//       }
//     }
//   };

//   return (
//     <div>
//       <div className="container">
//         <div className="py-4">
//           <h2 className="text-center">All Approved Feeds</h2>
//           <Table striped="columns" className="border mt-3">
//             <thead>
//               <tr>
//                 <th>Sr</th>
//                 <th>Feed</th>
//                 <th>Created By</th>
//                 <th>Date Created</th>
//                 <th>Approval</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {feeds.map((feed, index) => (
//                 <tr key={feed.feedId}>
//                   <td>{index + 1}</td>
//                   <td>{feed.postDescription}</td>
//                   <td>{feed.createdBy}</td>
//                   <td>{feed.dateCreated}</td>
//                   <td>{feed.approval}</td>
//                   <td>
//                     <Link
//                       className="btn btn-primary mx-2"
//                       to={`/viewFeed/${feed.feedId}`}
//                     >
//                       View
//                     </Link>
//                     {/* Uncomment the following lines if you want to add edit and delete functionality */}
//                     {/* <Link
//                       className="btn btn-outline-primary mx-2"
//                       to={`/editFeed/${feed.feedId}`}
//                     >
//                       Edit
//                     </Link>
//                     <button
//                       className="btn btn-danger mx-2"
//                       onClick={() => deleteFeed(feed.feedId)}
//                     >
//                       Delete
//                     </button> */}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </Table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeed;







// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeed = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     const userData = JSON.parse(localStorage.getItem("userData"));
//     if (userData && userData.userEmail) {
//       const userEmail = userData.userEmail;
//       try {
//         const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//         const approvedFeeds = result.data.filter(
//           (feed) => feed.approval === "Approved" && feed.createdBy !== userEmail
//         );
//         setFeeds(approvedFeeds);
//       } catch (error) {
//         console.error("Error fetching feeds", error);
//       }
//     } else {
//       console.error("User email not found in localStorage");
//     }
//   };

//   const deleteFeed = async (id) => {
//     const confirmDelete = window.confirm(
//       "Are you sure you want to delete this feed?"
//     );

//     if (confirmDelete) {
//       try {
//         await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
//         loadFeeds(); // Reload feeds after deletion
//       } catch (error) {
//         console.error("Error deleting feed", error);
//       }
//     }
//   };

//   return (
//     <div>
//       <div className="container">
//         <div className="py-4">
//           <h2 className="text-center">All Feeds</h2>
//           <Table striped="columns" className="border mt-3">
//             <thead>
//               <tr>
//                 <th>Sr</th>
//                 <th>Feed</th>
//                 <th>Created By</th>
//                 <th>Date Created</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {feeds.map((feed, index) => (
//                 <tr key={feed.feedId}>
//                   <td>{index + 1}</td>
//                   <td>{feed.postDescription}</td>
//                   <td>{feed.createdBy}</td>
//                   <td>{feed.dateCreated}</td>
//                   <td>
//                     <Link
//                       className="btn btn-primary mx-2"
//                       to={`/viewFeed/${feed.feedId}`}
//                     >
//                       View
//                     </Link>
//                     {/* Uncomment the following lines if you want to add edit and delete functionality */}
//                     {/* <Link
//                       className="btn btn-outline-primary mx-2"
//                       to={`/editFeed/${feed.feedId}`}
//                     >
//                       Edit
//                     </Link>
//                     <button
//                       className="btn btn-danger mx-2"
//                       onClick={() => deleteFeed(feed.feedId)}
//                     >
//                       Delete
//                     </button> */}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </Table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeed;






// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeed = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     try {
//       const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//       // Filter feeds to only include those marked as Approved
//       const approvedFeeds = result.data.filter(feed => feed.approval === "Approved");
//       setFeeds(approvedFeeds);
//     } catch (error) {
//       console.error("Error fetching feeds", error);
//     }
//   };

//   const deleteFeed = async (id) => {
//     const confirmDelete = window.confirm(
//       "Are you sure you want to delete this feed?"
//     );

//     if (confirmDelete) {
//       try {
//         await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
//         loadFeeds(); // Reload feeds after deletion
//       } catch (error) {
//         console.error("Error deleting feed", error);
//       }
//     }
//   };

//   return (
//     <div>
//       <div className="container">
//         <div className="py-4">
//           <h2 className="text-center">All Feeds</h2>
//           <Table striped="columns" className="border mt-3">
//             <thead>
//               <tr>
//                 <th>Sr</th>
//                 <th>Feed</th>
//                 <th>Created By</th>
//                 <th>Date Created</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {feeds.map((feed, index) => (
//                 <tr key={feed.feedId}>
//                   <td>{index + 1}</td>
//                   <td>{feed.postDescription}</td>
//                   <td>{feed.createdBy}</td>
//                   <td>{feed.dateCreated}</td>
//                   <td>
//                     <Link
//                       className="btn btn-primary mx-2"
//                       to={`/viewFeed/${feed.feedId}`}
//                     >
//                       View
//                     </Link>
//                     {/* Uncomment the following lines if you want to add edit and delete functionality */}
//                     {/* <Link
//                       className="btn btn-outline-primary mx-2"
//                       to={`/editFeed/${feed.feedId}`}
//                     >
//                       Edit
//                     </Link>
//                     <button
//                       className="btn btn-danger mx-2"
//                       onClick={() => deleteFeed(feed.feedId)}
//                     >
//                       Delete
//                     </button> */}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </Table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeed;



// import React, { useEffect, useState } from "react";
// import Table from "react-bootstrap/Table";
// import axios from "axios";
// import { Link } from "react-router-dom";

// const AllFeed = () => {
//   const [feeds, setFeeds] = useState([]);

//   useEffect(() => {
//     loadFeeds();
//   }, []);

//   const loadFeeds = async () => {
//     const result = await axios.get("http://localhost:8080/fetchAllFeeds");
//     setFeeds(result.data);
//   };

//   const deleteFeed = async (id) => {
//     const confirmDelete = window.confirm(
//       "Are you sure you want to delete this feed?"
//     );

//     if (confirmDelete) {
//       await axios.delete(`http://localhost:8080/deleteFeedById/${id}`);
//       loadFeeds();
//     }
//   };

//   return (
//     <div>
//       <div className="container">
//         <div className="py-4">
//           <h2 className="text-center">All Feeds</h2>
//           <Table striped="columns" className="border mt-3">
//             <thead>
//               <tr>
//                 <th>Sr</th>
//                 <th>Feed</th>
//                 <th>Created By</th>
//                 <th>Date Created</th>
//                 <th>Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {feeds.map((feed, index) => (
//                 <tr>
//                   <td key={index}>{index + 1}</td>
//                   <td>{feed.postDescription}</td>
//                   <td>{feed.createdBy}</td>
//                   <td>{feed.dateCreated}</td>
//                   <td>
//                     <Link
//                       className="btn btn-primary mx-2"
//                       to={`/viewFeed/${feed.feedId}`}
//                     >
//                       View
//                     </Link>
//                     {/* <Link className='btn btn-outline-primary mx-2' to={`/editVehicle/${feed.id}`}>Edit</Link>
//                   <Link className='btn btn-danger mx-2' onClick={()=>deleteFeed(feed.id)}>Delete</Link> */}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </Table>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AllFeed;
