import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import axios from "axios";
import { Link, useNavigate, useParams } from "react-router-dom";

const EditFeed = () => {
  const { id } = useParams();

  let navigate = useNavigate();

  // constructing an object
  const [feed, setFeed] = useState({
    postDescription: "",
    dateCreated: "",
    createdBy: "",
  });

  const { postDescription, dateCreated, createdBy } = feed;

  const onInputChange = (e) => {
    setFeed({ ...feed, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:8080/updateFeedById/${id}`, feed);
    navigate("/userFeed");
  };

  useEffect(() => {
    loadFeed();
  }, []);

  const loadFeed = async () => {
    const result = await axios.get(`http://localhost:8080/fetchFeedById/${id}`);
    setFeed(result.data);
  };

  return (
    <div>
      <div className="d-flex align-items-center justify-content-center vh-100">
        <div className="container mt-2">
          <section className="d-flex justify-content-center">
            <div className="left_data mt-2 p-3" style={{ width: "100%" }}>
              <h3 className="text-center col-lg-12 my-3">Update Feed</h3>
              <Form onSubmit={(e) => onSubmit(e)}>
                <Form.Group className="mb-3 col-lg-6 mt-3 mx-auto">
                  <Form.Control
                    type="text"
                    name="postDescription"
                    value={postDescription}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Update Feed"
                  />
                </Form.Group>

                <Form.Group className="mb-3 col-lg-6 mx-auto">
                  <Form.Control
                    type="date"
                    name="dateCreated"
                    value={dateCreated}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Update Feed Date"
                  />
                </Form.Group>

                <Form.Group className="mb-3 col-lg-6 mx-auto">
                  <Form.Control
                    type="email"
                    name="createdBy"
                    value={createdBy}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Update Created By"
                    readOnly
                  />
                </Form.Group>

                <Button
                  variant="primary"
                  className="col-lg-6 mt-2 mx-auto d-block"
                  style={{ background: "black" }}
                  type="submit"
                >
                  Update
                </Button>
              </Form>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default EditFeed;
