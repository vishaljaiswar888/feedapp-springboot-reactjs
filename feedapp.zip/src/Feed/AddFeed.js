import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AddFeed = () => {
    let navigate = useNavigate();

    const [feed, setFeed] = useState({
        postDescription: "",
        dateCreated: ""
    });

    const { postDescription, dateCreated } = feed;

    const onInputChange = (e) => {
        setFeed({ ...feed, [e.target.name]: e.target.value });
    }

    const onSubmit = async (e) => {
        e.preventDefault();

        const userData = JSON.parse(localStorage.getItem('userData'));

        if (!userData) {
            alert("User is not logged in.");
            navigate("/login");
            return;
        }

        const createdBy = userData.userEmail;

        if (postDescription.trim() === "") {
            alert("Post Description is required!");
        } else if (dateCreated.trim() === "") {
            alert("Date Created is required!");
        } else {
            try {
                await axios.post("http://localhost:8080/addFeed", { postDescription, dateCreated, createdBy });
                alert("Feed added successfully.");
                setFeed({ postDescription: "", dateCreated: "" });
                navigate("/addFeed", { replace: true });
            } catch (error) {
                console.error("Error:", error);
            }
        }
    }

    return (
        <div className="d-flex justify-content-center align-items-center vh-100">
            <div className="container mt-2">
                <section className='d-flex justify-content-center'>
                    <div className="left_data p-4" style={{ width: "100%", maxWidth: "500px", boxShadow: "0 0 10px rgba(0,0,0,0.1)" }}>
                        <h3 className='text-center mb-5'>Add Feed</h3>
                        <Form onSubmit={onSubmit}>
                            <Form.Group className="mb-3 mt-3">
                                <Form.Control type="text" name='postDescription' value={postDescription} onChange={onInputChange} placeholder="Post Description" />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="date" name='dateCreated' value={dateCreated} onChange={onInputChange} placeholder="Date Created" />
                            </Form.Group>
                            <Button variant="primary" className='w-100 mt-2' style={{ background: "black" }} type="submit">
                                Submit
                            </Button>
                        </Form>
                    </div>
                </section>
            </div>
        </div>
    )
}

export default AddFeed;
