import React from 'react'
import { Link } from 'react-router-dom';

const AdminPanel = () => {
  return (
    <div>
        <div className="container">
      <div className="row">
        <div className="col-md-8 offset-md-2 border rounded p-4 mt-5 shadow text-center">
          <h2 className="text-center m-4">Welcome back, Admin!</h2>
          
          <form>
            <Link className="btn btn-outline-danger mx-2" to="/allFeedAdmin"
              style={{ fontSize: '24px', padding: '20px', width: '300px', marginTop: '20px', marginBottom: '20px' }}>
                Not Approved Feeds
            </Link>
            <Link className="btn btn-outline-success mx-2" to="/allFeedAdminApproved"
              style={{ fontSize: '24px', padding: '20px', width: '300px', marginTop: '20px', marginBottom: '20px' }}>
                Approved Feeds
            </Link>
          </form>
        </div>
      </div>
    </div>
    </div>
  )
}

export default AdminPanel