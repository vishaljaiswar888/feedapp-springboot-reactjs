import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import { NavLink, useNavigate } from 'react-router-dom';

const Register = () => {
    let navigate = useNavigate();

    const [user, setUser] = useState({
        userName: "",
        userEmail: "",
        userPhone: "",
        userPass: "",
        userCPass: ""
    });

    const { userName, userEmail, userPhone, userPass, userCPass } = user;

    const onInputChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    }

    const onSubmit = async (e) => {
        e.preventDefault();

        if (userName.trim() === "") {
            alert("Full Name is required!");
        } else if (userEmail.trim() === "") {
            alert("Email is required!");
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userEmail)) {
            alert("Please enter a valid email address.");
        } else if (userPhone.trim() === "") {
            alert("Phone number is required!");
        } else if (!/^[6-9]\d{9}$/.test(userPhone)) {
            alert("Please enter a valid phone number.");
        } else if (userPass === "") {
            alert("Password is required!");
        } else if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/.test(userPass)) {
            alert("Password should be at least 6 characters long and contain at least one numeric digit, one uppercase and one lowercase letter.");
        } else if (userPass !== userCPass) {
            alert("Password and Confirm Password did not match.");
        } else {
            try {
                const response = await axios.get("http://localhost:8080/fetchAllUsers");
                const existingEmails = response.data.map(user => user.userEmail);
                if (existingEmails.includes(userEmail)) {
                    alert("User with this email already exists. Please use a different email.");
                } else {
                    await axios.post("http://localhost:8080/addUser", { userName, userEmail, userPhone, userPass });
                    console.log("Registration successful.");
                    alert("Registration Successful.");
                    setUser({ userName: "", userEmail: "", userPhone: "", userPass: "", userCPass: "" });
                    navigate("/login", { replace: true });
                }
            } catch (error) {
                console.error("Error:", error);
            }
        }
    }

    return (
        <div className="d-flex justify-content-center align-items-center vh-100">
            <div className="container mt-2">
                <section className='d-flex justify-content-center'>
                    <div className="left_data p-4" style={{ width: "100%", maxWidth: "500px", boxShadow: "0 0 10px rgba(0,0,0,0.1)" }}>
                        <h3 className='text-center mb-5'>Register</h3>
                        <Form onSubmit={onSubmit}>
                            <Form.Group className="mb-3 mt-3">
                                <Form.Control type="text" name='userName' value={userName} onChange={onInputChange} placeholder="Your Full Name" />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="email" name='userEmail' value={userEmail} onChange={onInputChange} placeholder="Enter Your Email" />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control
                                    type="tel"
                                    name="userPhone"
                                    value={userPhone}
                                    onChange={onInputChange}
                                    placeholder="Enter Your Phone Number"
                                />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="password" name='userPass' value={userPass} onChange={onInputChange} placeholder="Enter Your Password" />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="password" name='userCPass' value={userCPass} onChange={onInputChange} placeholder="Confirm Your Password" />
                            </Form.Group>
                            <Button variant="primary" className='w-100 mt-2' style={{ background: "black" }} type="submit">
                                Submit
                            </Button>
                            <p className='mt-2 text-center'>Already have an account? <NavLink to="/login">Login</NavLink></p>
                        </Form>
                    </div>
                </section>
            </div>
        </div>
    )
}

export default Register;




