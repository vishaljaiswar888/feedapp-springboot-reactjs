import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import { NavLink, useNavigate } from 'react-router-dom';

const Login = () => {
    let navigate = useNavigate();

    const [user, setUser] = useState({
        userEmail: "",
        userPass: ""
    });

    const { userEmail, userPass } = user;

    const onInputChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    }

    const onSubmit = async (e) => {
        e.preventDefault();

        if (userEmail.trim() === "" || userPass.trim() === "") {
            alert("Email and password are required!");
            return;
        }

        try {
            const response = await axios.post("http://localhost:8080/login", user);
            if (response.status === 200) {
                const userData = response.data;
                localStorage.setItem('userData', JSON.stringify(userData));
                if (userData.userRole === 'Customer') {
                    navigate("/userPanel", { replace: true });
                } else if (userData.userRole === 'Admin') {
                    navigate("/adminPanel", { replace: true });
                }
            } else {
                alert("Invalid email or password");
            }
        } catch (error) {
            console.error("Error:", error);
        }
    }

    return (
        <div className="d-flex justify-content-center align-items-center vh-100">
            <div className="container mt-2">
                <section className='d-flex justify-content-center'>
                    <div className="left_data p-4" style={{ width: "100%", maxWidth: "500px", boxShadow: "0 0 10px rgba(0,0,0,0.1)" }}>
                        <h3 className='text-center mb-5'>Login</h3>
                        <Form onSubmit={onSubmit}>
                            <Form.Group className="mb-3 mt-3">
                                <Form.Control type="email" name='userEmail' value={userEmail} onChange={onInputChange} placeholder="Your Email" />
                            </Form.Group>
                            <Form.Group className="mb-3">
                                <Form.Control type="password" name='userPass' value={userPass} onChange={onInputChange} placeholder="Your Password" />
                            </Form.Group>
                            <Button variant="primary" className='w-100 mt-2' style={{ background: "black" }} type="submit">
                                Submit
                            </Button>
                            <p className='mt-2 text-center'>Don't have an account? <NavLink to="/register">Register</NavLink></p>
                        </Form>
                    </div>
                </section>
            </div>
        </div>
    )
}

export default Login;




// import React, { useState } from 'react';
// import Form from 'react-bootstrap/Form';
// import Button from 'react-bootstrap/Button';
// import axios from 'axios';
// import { NavLink, useNavigate } from 'react-router-dom';

// const Login = () => {
//     let navigate = useNavigate();

//     const [user, setUser] = useState({
//         userEmail: "",
//         userPass: ""
//     });

//     const { userEmail, userPass } = user;

//     const onInputChange = (e) => {
//         setUser({ ...user, [e.target.name]: e.target.value });
//     }

//     const onSubmit = async (e) => {
//         e.preventDefault();

//         if (userEmail.trim() === "" || userPass.trim() === "") {
//             alert("Email and password are required!");
//             return;
//         }

//         try {
//             const response = await axios.post("http://localhost:8080/login", user);
//             if (response.data === "Login successful") {
//                 alert("Login Successful.");
//                 navigate("/", { replace: true });
//             } else {
//                 alert("Invalid email or password");
//             }
//         } catch (error) {
//             console.error("Error:", error);
//         }
//     }

//     return (
//         <div className="d-flex justify-content-center align-items-center vh-100">
//             <div className="container mt-2">
//                 <section className='d-flex justify-content-center'>
//                     <div className="left_data p-4" style={{ width: "100%", maxWidth: "500px", boxShadow: "0 0 10px rgba(0,0,0,0.1)" }}>
//                         <h3 className='text-center mb-5'>Login</h3>
//                         <Form onSubmit={onSubmit}>
//                             <Form.Group className="mb-3 mt-3">
//                                 <Form.Control type="email" name='userEmail' value={userEmail} onChange={onInputChange} placeholder="Your Email" />
//                             </Form.Group>
//                             <Form.Group className="mb-3">
//                                 <Form.Control type="password" name='userPass' value={userPass} onChange={onInputChange} placeholder="Your Password" />
//                             </Form.Group>
//                             <Button variant="primary" className='w-100 mt-2' style={{ background: "black" }} type="submit">
//                                 Submit
//                             </Button>
//                             <p className='mt-2 text-center'>Don't have an account? <NavLink to="/register">Register</NavLink></p>
//                         </Form>
//                     </div>
//                 </section>
//             </div>
//         </div>
//     )
// }

// export default Login;
