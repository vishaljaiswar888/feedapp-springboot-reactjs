import React, { useEffect, useState } from "react";
import Table from "react-bootstrap/Table";
import axios from "axios";
import { Link } from "react-router-dom";

const AllUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const result = await axios.get("http://localhost:8080/fetchAllUsers");
      setUsers(result.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const deleteUser = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this user?"
    );

    if (confirmDelete) {
      try {
        await axios.delete(`http://localhost:8080/deleteUserById/${id}`);
        loadUsers();
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };

  return (
    <div>
      <div>
        <div className="container">
          <div className="py-4">
            <h2 className="text-center">All Users</h2>
            <Table striped bordered hover className="border mt-3">
              <thead>
                <tr>
                  <th>Sr</th>
                  <th>User Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, index) => (
                  <tr key={user.userId}>
                    <td>{index + 1}</td>
                    <td>{user.userName}</td>
                    <td>{user.userEmail}</td>
                    <td>{user.userPhone}</td>
                    <td>
                    <Link
                        className="btn btn-primary mx-2"
                        to={`/viewUsers/${user.userId}`}
                      >
                        View
                      </Link>

                      <Link
                        className="btn btn-outline-primary mx-2"
                        to={`/editUser/${user.userId}`}
                      >
                        Edit
                      </Link>
                      
                      <button
                        className="btn btn-danger mx-2"
                        onClick={() => deleteUser(user.userId)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllUsers;
