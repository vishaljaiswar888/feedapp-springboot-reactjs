import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const ViewUsers = () => {
  const [user, setUser] = useState({
    userName: "",
    userEmail: "",
    userPhone: "",
    userRole: ""
  });

  const { id } = useParams();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const result = await axios.get(`http://localhost:8080/fetchUserById/${id}`);
      setUser(result.data);
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };

  return (
    <div>
      <div>
        <div className="container mt-2">
          <section className="d-flex justify-content-between">
            <div className="left_data mt-2 p-3" style={{ width: "100%" }}>
              <h3 className="text-center col-lg-12 my-5">User Detail</h3>

              <div className="row gutters-sm mt-3 justify-content-center">
                <div className="col-md-8">
                  <div className="card mb-3">
                    <div className="card-body">
                      <div className="row">
                        <div className="col-sm-3">
                          <h6 className="mb-0">User Name</h6>
                        </div>
                        <div className="col-sm-9 text-secondary">
                          {user.userName}
                        </div>
                      </div>
                      <br />
                      <div className="row">
                        <div className="col-sm-3">
                          <h6 className="mb-0">Email</h6>
                        </div>
                        <div className="col-sm-9 text-secondary">
                          {user.userEmail}
                        </div>
                      </div>
                      <br />
                      <div className="row">
                        <div className="col-sm-3">
                          <h6 className="mb-0">Phone</h6>
                        </div>
                        <div className="col-sm-9 text-secondary">
                          {user.userPhone}
                        </div>
                      </div>
                      <br />
                      <div className="row">
                        <div className="col-sm-3">
                          <h6 className="mb-0">Role</h6>
                        </div>
                        <div className="col-sm-9 text-secondary">
                          {user.userRole}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ViewUsers;
