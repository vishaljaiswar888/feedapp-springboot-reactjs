import React, { useEffect, useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import axios from "axios";
import { Link, useNavigate, useParams } from "react-router-dom";

const EditUser = () => {
  const { id } = useParams();

  let navigate = useNavigate();

  // constructing an object
  const [user, setUser] = useState({
    userName: "",
    userEmail: "",
    userPhone: "",
    userRole: "",
  });

  const { userName, userEmail, userPhone, userRole } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`http://localhost:8080/updateUserById/${id}`, user);
    navigate("/allUsersAdmin");
  };

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const result = await axios.get(`http://localhost:8080/fetchUserById/${id}`);
    setUser(result.data);
  };

  return (
    <div>
      <div className="d-flex align-items-center justify-content-center vh-100">
        <div className="container mt-2">
          <section className="d-flex justify-content-center">
            <div className="left_data mt-2 p-3" style={{ width: "100%" }}>
              <h3 className="text-center col-lg-12 my-3">Edit User</h3>
              <Form onSubmit={(e) => onSubmit(e)}>
                <Form.Group className="mb-3 col-lg-6 mt-3 mx-auto">
                  <Form.Control
                    type="text"
                    name="userName"
                    value={userName}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Edit User Name"
                  />
                </Form.Group>

                <Form.Group className="mb-3 col-lg-6 mx-auto">
                  <Form.Control
                    type="email"
                    name="userEmail"
                    value={userEmail}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Edit User Email"
                  />
                </Form.Group>

                <Form.Group className="mb-3 col-lg-6 mx-auto">
                  <Form.Control
                    type="tel"
                    name="userPhone"
                    value={userPhone}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Edit User Phone"
                  />
                </Form.Group>

                <Form.Group className="mb-3 col-lg-6 mx-auto">
                  <Form.Control
                    type="text"
                    name="userRole"
                    value={userRole}
                    onChange={(e) => onInputChange(e)}
                    placeholder="Edit User Role"
                  />
                </Form.Group>

                <Button
                  variant="primary"
                  className="col-lg-6 mt-2 mx-auto d-block"
                  style={{ background: "black" }}
                  type="submit"
                >
                  Update
                </Button>
              </Form>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default EditUser;
